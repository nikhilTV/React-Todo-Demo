import React from 'react'
import './Heading.css'

function Heading() {
    return (
        <div className="Todo_Heading">
            <h1 >Todo List</h1>
            
        </div>
    )
}

export default Heading
